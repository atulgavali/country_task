<?php
class Country_model extends CI_Model{
	function __construct() {
		parent::__construct();
	}
	function form_insert($data){
		// Inserting in Table data in table
		$this->db->insert('country', $data);
	}
	function get_country(){
		// get data from Table
		return $this->db->get('country')->result();
	}
	function get_details($id){
		// get perticular record from Table 
		return $this->db->get_where('country', array('id' => $id))->result();
	}
}
?>