<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->library("session");
		$this->load->model('Country_model');
		$this->load->helper('url');
	}

	public function index()
	{
		$data['data'] = $this->Country_model->get_country();
		$this->load->view('list',$data);
	}
	
	public function add()
	{
		$this->load->view('task');
	}
	
	public function add_country(){
		$data['country'] 		= $this->input->post('country');
		$data['top_domain'] 	= $this->input->post('top_level_domain');
		$data['alpha2_code'] 	= $this->input->post('alpha2_code');
		$data['alpha3_code'] 	= $this->input->post('alpha2_code');
		$data['calling_code']	= $this->input->post('calling_code');
		$data['time_zones'] 	= $this->input->post('time_zones');
		$data['currencies'] 	= $this->input->post('currencies');
		$data['country_flag'] 	= $this->input->post('country_flag');
		$data['p_time'] 		= $this->input->post('p_time');
		$this->Country_model->form_insert($data);
		$this->session->set_flashdata('success', 'Data added successfully');
		redirect(base_webroot_url.'index.php/welcome/index');
	}
	public function details($id)
	{
		$data['data'] = $this->Country_model->get_details($id);
		$this->load->view('details',$data);
	}
}
