<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>List</title>
	<link rel="stylesheet" href="<?php echo base_webroot_url ?>assets/css/bootstrap.min.css">
    <script src="<?php echo base_webroot_url ?>assets/js/jquery.min.js"></script>
	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>










	<div class="container-fluid">
                                
        <div class="row">
        	<div class="col-md-8 col-sm-offset col-xs-12 col-md-offset-2 col-sm-offset-1">
        		
                <div class="row">
                	<div class="col-sm-6 col-xs-12">
            			<h1>Country List</h1>
             		</div>
             		<div class="col-sm-6 col-xs-12">
             			<div class="text-right">
             				<a href="<?php echo base_webroot_url ?>index.php/welcome/add" class="btn btn-primary" >Add New</a>
             			</div>
             		</div>
             	</div>
                
                <div class="table-responsive">          
                    <table class="table table-bordered">
                    	<thead>
                            <tr>
                              <th>Sr No</th>
                              <th>Country</th>
                              <th>Calling Code</th>
                              <th>Time Zone</th>
                              <th>Currency</th>                                            
                              <th>Action</th>
                            </tr>
                      	</thead>
                      	<tbody>
				  			<?php
							foreach($data as $key=>$value)
							{
							?>
                    		<tr>                     
                              <td><?php echo $key+1; ?></td>
                              <td><?php echo $value->country; ?></td>
                              <td><?php echo $value->calling_code; ?></td>
                              <td><?php echo $value->time_zones; ?></td>
                              <td><?php echo $value->currencies; ?></td>
                              <td>
                              <a href="<?php echo base_webroot_url.'index.php/welcome/details/'.$value->id ?>" >
                                <button type="button" class="btn btn-success">Show</button>
                                </a> 
							  </td>
                    		</tr>
							<?php
                            }
                            ?>
                  		</tbody>
                	</table>
                </div>
                
			</div>                
		</div>                
	</div>                
 
</body>
</html>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">


<script type="text/javascript">


	<?php if($this->session->flashdata('success')){ ?>
		toastr.success("<?php echo $this->session->flashdata('success'); ?>");
	<?php }else if($this->session->flashdata('error')){  ?>
		toastr.error("<?php echo $this->session->flashdata('error'); ?>");
	<?php }else if($this->session->flashdata('warning')){  ?>
		toastr.warning("<?php echo $this->session->flashdata('warning'); ?>");
	<?php }else if($this->session->flashdata('info')){  ?>
		toastr.info("<?php echo $this->session->flashdata('info'); ?>");
	<?php } ?>


</script>