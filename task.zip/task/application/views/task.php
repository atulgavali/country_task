<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Add Country</title>
	<link rel="stylesheet" href="<?php echo base_webroot_url ?>assets/css/bootstrap.min.css">
    <script src="<?php echo base_webroot_url ?>assets/js/jquery.min.js"></script>
	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>










	<div class="container-fluid">
                                
        <div class="row">
        	<div class="col-md-8 col-sm-offset col-xs-12 col-md-offset-2 col-sm-offset-1">
        
        		<h1>Country Task</h1>
        		<form autocomplete="off" action="<?php echo base_webroot_url.'index.php/welcome/add_country' ?>" method="post" enctype="multipart/form-data">
                <div class="row">
        			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">        
        				<div class="form-group">
                            <h5>Country Name</h5>
                             <select class="selectpicker form-control country" name="country" required>
                              <option value=""> Select Country</option>
                            </select>
        				</div>        
        			</div>
        
        			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">        
       	 				<div class="form-group">
         					<h5>Top Level Domain</h5>
	         				<input type='text' class="form-control top_domain" name="top_level_domain" required />
		         		</div>         
        			</div>
        		</div>
                
                <div class="row">
        			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">        
        				<div class="form-group">
                            <h5>Alpha2 Code</h5>
                             <input type='text' class="form-control alpha2_code" name="alpha2_code" required />
        				</div>        
        			</div>
        
        			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">        
       	 				<div class="form-group">
         					<h5>Alpha3 Code</h5>
                             <input type='text' class="form-control alpha3_code" name="alpha3_code" required />
		         		</div>         
        			</div>
        		</div>
                
                <div class="row">
        			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">        
        				<div class="form-group">
                            <h5>Calling Code</h5>
                             <input type='text' class="form-control calling_code" name="calling_code" required />
        				</div>        
        			</div>
        
        			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">        
       	 				<div class="form-group">
         					<h5>Time Zones</h5>
                             <input type='text' class="form-control time_zones" name="time_zones" required />
		         		</div>         
        			</div>
        		</div>
                
                <div class="row">
        			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">        
        				<div class="form-group">
                            <h5>Currencies</h5>
                             <input type='text' class="form-control currencies" name="currencies" required />
        				</div>        
        			</div>
        
        			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">        
       	 				<div class="form-group">
         					<h5>Country Flag</h5>
                             <input type='text' class="form-control country_flag" name="country_flag" required />
		         		</div>         
        			</div>
        		</div>
                
                <div class="row">
        			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">        
        				<div class="form-group">
                            <h5>Publish Time</h5>
                             <input type='text' class="form-control p_time" name="p_time" required />
        				</div>        
        			</div>
        		</div>
                
                <div class="row">
        			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">        
        				<div class="form-group">
                        	<button type="submit" class="btn btn-primary">Submit</button>
        				</div>        
        			</div>
        		</div>
                </form>
			</div>                
		</div>                
	</div>                
 
</body>
</html>

<script>
	$(document).ready(function(){
		$('.top_domain').val('');
		$('.alpha2_code').val('');
		$('.alpha3_code').val('');
		$('.calling_code').val('');
		$('.time_zones').val('');
		$('.currencies').val('');
		$('.country_flag').val('');
		$('.p_time').val('');
		var all_data = '';
		$.ajax({
			type: 'GET',
			url: "https://restcountries.eu/rest/v2/all",
			dataType: "json",
			success: function(resultData) {
				all_data = resultData;
				var country_option = '<option value=""> Select Country</option>';
				$.each(resultData, function(key,value){
					country_option += '<option value="'+value.name+'">'+value.name+'</option>';
				});
				$('.country option').remove();
				$('.country').append(country_option);
			}
		});
		$(document).on("change", ".country", function(){
			var current_country = $('.country').val();
			if(current_country.trim() != ''){
				$.each(all_data, function(key,value){
					if(value.name == current_country){						
						var timeZone = value.timezones[0].split("+");
						if(timeZone[1] == undefined){
							timeZone = value.timezones[0].split("-");
						}						
						timeZone = timeZone[1].replace(":", ".");
						var date = new Date();
						var utc = date.getTime() + (date.getTimezoneOffset() * 60000);
						var utcLocal = new Date(utc + (3600000*timeZone));
						var utcDate = utcLocal.toLocaleString();
						utcDate = utcDate.split(" ");
						if(utcDate[2] == undefined)
							var utcTime = utcDate[1];
						else
							var utcTime = utcDate[1]+' '+utcDate[2];
						utcDate = utcDate[0].replace(",", "");
						utcDate = utcDate.split("/");
						$('.top_domain').val(value.topLevelDomain);
						$('.alpha2_code').val(value.alpha2Code);
						$('.alpha3_code').val(value.alpha3Code);
						$('.calling_code').val(value.callingCodes);
						$('.time_zones').val(value.timezones);
						$('.currencies').val(value.currencies[0]['symbol']);
						$('.country_flag').val(value.flag);
						$('.p_time').val(utcDate[2]+'-'+utcDate[0]+'-'+utcDate[1]+' '+utcTime);
					}
				});
			}
			else{
				
			}
		});
	});
</script>